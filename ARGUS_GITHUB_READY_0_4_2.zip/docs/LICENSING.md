# Licensing and source-data note

The new ARGUS source code distributed in this repository is released under the MIT License in the repository root. The historical legacy scripts and proprietary or externally licensed data are excluded. The MIT license is not a relicense of Vesuvius Challenge imaging data, upstream software, raw captured data, or documentation not authored for this project.

Derivative figures and summaries cite source datasets and should be used subject to their original data terms. Please verify Vesuvius Challenge source-data permissions and reuse conditions independently before redistributing raw data.

The supporting Google Drive folder is distinct from the source repository; external access to it requires that its sharing permissions be set appropriately.
