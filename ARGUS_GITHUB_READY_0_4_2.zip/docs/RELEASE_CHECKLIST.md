# October public-release checklist

- [x] Six-case selected demonstration frozen with source-derived report, CSV and figures.
- [x] New 24-cell outcome-independent selection fixed before those keys were inspected remotely.
- [x] Capture utility, stable result filename, error ZIP, source hash and HTTP receipts.
- [x] Standalone local tests with simulated network conditions; full research bundle regressions.
- [x] Reproduction documentation and local source-release candidate.
- [x] Run the real Windows held-out capture; upload and independently decode raw bytes. (13 source chunks, all 24 cells; separately verified)
- [ ] Perform physically meaningful registration comparison before describing papyrus or phantom geometry.
- [ ] Demonstrate a concrete advantage or complementary feature relative to existing audit/cleanup tools.
- [ ] Clean-room Windows Python 3.13 test and external reproduction, beyond synthetic server tests.
- [ ] Complete licensing and public-data redistribution review. Public release candidate excludes unlicensed legacy/ and raw uploaded user captures.
- [ ] Publish source on a public GitHub repository with a Git tag/commit SHA and runnable README.
- [ ] Invite informed reviewer feedback (Vesuvius community / GitHub issue, not unsolicited bulk posting).
- [ ] Replace draft placeholders only with verified findings, public URLs and benchmark data.
- [ ] Submit official October Progress Prize form (listed Oct 31, 2026 11:59pm Pacific). Aim to freeze/submission by Oct 30.

No public release has occurred simply because ZIPs were generated. Do not write "released," "prize submitted," "phantom surface proved," or "ink detected" until independently established.
