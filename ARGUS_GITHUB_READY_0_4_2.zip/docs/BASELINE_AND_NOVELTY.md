# Honest comparison with published phantom audit

Schurkai's public [vesuvius-phantom-audit](https://github.com/Schurkai/vesuvius-phantom-audit) already reports all 36 published samples, 9,255 certain-phantom chunks of 52,062 prediction chunks in PHerc0211 (17.8% as a whole-scroll *chunk count*), voxel-level testing on selected slices and a cleanup tool that masks predicted regions where masked CT is zero. ARGUS should not duplicate this work and call it an invention.

| Dimension | Public phantom audit | ARGUS 0.4 candidate |
|---|---|---|
| Breadth | All 36 samples, chunk key inventory | Tiny targeted PHerc0211 R04-region selection |
| Voxel-level analysis | Yes, selected mid-height planes / boundary cleanup | Yes, all sampled prediction blocks with exact per-CT-overlap positive counts |
| Sampling | Scroll-wide chunk coverage + targeted slices | Frozen 24-cell local selection not conditional on held-out predictions/CT status |
| Provenance | Published code, results and figures | Additional raw chunk capture archive + per-request HTTP receipts / byte hashes |
| Physical geometry | Does not establish ink | ARGUS also does **not** establish ink or physical surface identity |
| Production maturity | Existing public workflow | Local release candidate, Windows live run pending |

This is **not** proof ARGUS is better. Before making a value-add claim, publish a concrete benchmark with comparable inputs: reproducible commands; source byte verification; boundary subset that chunk-only summary cannot express; error and network failure behavior; runtime and memory on Windows; and a real user action enabled by an output. If comparable functionality exists upstream, consider contributing a small pull request to that project instead of claiming competing invention.
